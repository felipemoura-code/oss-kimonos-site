'use strict';
const state={products:[],category:'',search:'',sort:'recent',cart:[]};
const $=id=>document.getElementById(id);
const fmt=n=>new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(Number(n)||0);
const allowedCategories=['Kimonos','Faixas','Rash Guards','Acessórios'];
const productList=$('products'),empty=$('empty');
try {let c=JSON.parse(localStorage.getItem('oss_cart')||'[]');if(Array.isArray(c))state.cart=c.filter(x=>typeof x?.id==='string'&&Number.isInteger(x.qty)&&x.qty>0)}catch(_){state.cart=[]}
const saveCart=()=>{try{localStorage.setItem('oss_cart',JSON.stringify(state.cart))}catch(_){} };
const close=()=>{$('drawer').classList.remove('on');$('overlay').classList.remove('on');$('drawer').setAttribute('aria-hidden','true');document.body.style.overflow='';};
const open=(title,html)=>{$('drawerTitle').textContent=title;$('drawerMain').innerHTML=html;$('drawerFooter').hidden=true;$('drawer').classList.add('on');$('overlay').classList.add('on');$('drawer').setAttribute('aria-hidden','false');document.body.style.overflow='hidden';$('closeDrawer').focus()};
$('overlay').addEventListener('click',close);$('closeDrawer').addEventListener('click',close);document.addEventListener('keydown',e=>{if(e.key==='Escape')close()});
$('menuOpen').addEventListener('click',()=>open('Navegação','<nav class="menu-links"><a href="#inicio">Início</a><a href="#categorias">Categorias</a><a href="#colecao">Produtos</a><a href="#guia-compra">Guia de compra</a><a href="#marca">A marca</a><a href="#instagram">Instagram</a><a href="#contato">Contato</a><a href="https://wa.me/5519997121912" target="_blank" rel="noopener noreferrer">WhatsApp</a></nav>'));
$('drawer').addEventListener('click',e=>{if(e.target.closest('.menu-links a'))close();if(e.target.closest('[data-remove]')){const id=e.target.closest('[data-remove]').getAttribute('data-remove');state.cart=state.cart.filter(x=>x.id!==id);saveCart();cartDrawer();}});
function cartDrawer(){
 const items=state.cart.map(x=>({...x,p:state.products.find(p=>p.id===(x.productId||x.id))})).filter(x=>x.p);
 const total=items.reduce((acc,x)=>acc+x.p.price*x.qty,0);
 const main=items.length?'<div class="mini-items">'+items.map(x=>`<div class="mini-item"><div><strong></strong><p style="margin:6px 0">${fmt(x.p.price)} × ${x.qty}</p><button type="button" data-remove="${x.id}">Remover</button></div><b>${fmt(x.p.price*x.qty)}</b></div>`).join('')+'</div>':'<p>Seu carrinho está vazio. Os produtos estarão disponíveis depois do cadastro oficial.</p>';
 open('Seu carrinho',main); const els=$('drawerMain').querySelectorAll('.mini-item strong');items.forEach((x,i)=>els[i].textContent=x.p.name+(x.size?' — '+x.size+' / '+x.color:''));
 $('drawerFooter').hidden=!items.length;if(items.length)$('drawerFooter').innerHTML=`<strong>Subtotal: ${fmt(total)}</strong><button class="btn dark" type="button" disabled title="Checkout ainda não configurado" style="opacity:.5;cursor:not-allowed">Pagamento em configuração</button><p class="note">Pedidos e cobranças não estão habilitados nesta prévia.</p>`;
}
$('cartOpen').addEventListener('click',cartDrawer);
$('searchOpen').addEventListener('click',()=>{document.querySelector('#colecao').scrollIntoView({behavior:'smooth'});$('searchInput').focus({preventScroll:true})});
function updateCount(){$('count').textContent=state.cart.reduce((s,x)=>s+x.qty,0)};
function safeImage(v){if(typeof v!=='string')return null;if(/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(v)&&v.length<1400000)return v;if(/^assets\/uploads\/[\w.-]+\.(webp|png|jpg|jpeg)$/i.test(v))return v;return null}
function render(){
 const query=state.search.toLocaleLowerCase('pt-BR');
 let list=state.products.filter(p=>(!state.category||p.category===state.category)&&(!query||p.name.toLocaleLowerCase('pt-BR').includes(query)));
 if(state.sort==='low')list.sort((a,b)=>a.price-b.price);if(state.sort==='high')list.sort((a,b)=>b.price-a.price);
 if(state.sort==='recent')list.sort((a,b)=>(b.createdAt||'').localeCompare(a.createdAt||''));
 $('resultCount').textContent=`${list.length} produto${list.length===1?'':'s'}`;
 productList.replaceChildren(); productList.hidden=!list.length;empty.hidden=!!list.length;
 $('empty').querySelector('p').textContent=state.products.length?'Nenhum produto encontrado para os filtros selecionados. Tente outra busca.':'Estamos organizando o catálogo com fotos, tamanhos e preços oficiais. Acompanhe o Instagram para conhecer os modelos.';
 for(const p of list){let node=document.createElement('article');node.className='product';let img=safeImage(p.image);if(img){let el=document.createElement('img');el.src=img;el.alt=p.name;el.loading='lazy';node.append(el)} else {let ph=document.createElement('div');ph.style.cssText='aspect-ratio:1;background:#ececea;display:grid;place-items:center;font-weight:bold;color:#777';ph.textContent='OSS KIMONOS';node.append(ph)}let info=document.createElement('div');info.className='product-text';let cat=document.createElement('small');cat.textContent=p.category;let name=document.createElement('h3');name.textContent=p.name;let price=document.createElement('strong');price.textContent=fmt(p.price);let btn=document.createElement('button');btn.type='button';btn.textContent='Adicionar ao carrinho';btn.disabled=p.stock<=0; if(btn.disabled)btn.textContent='Indisponível'; if(Array.isArray(p.variants)&&p.variants.length){btn.textContent='Escolher tamanho';btn.disabled=false;}btn.addEventListener('click',()=>{if(Array.isArray(p.variants)&&p.variants.length){const available=p.variants.filter(v=>v.stock>0);if(!available.length){alert('Nenhum tamanho disponível');return} const sizes=available.map(v=>v.size+' / '+v.color).join(', ');const chosen=prompt('Informe o tamanho e cor exatamente como listado: '+sizes);if(!chosen)return;const v=available.find(x=>x.size+' / '+x.color===chosen.trim());if(!v){alert('Variação inválida');return}const vid=p.id+'--'+v.size+'--'+v.color;const old=state.cart.find(x=>x.id===vid);if(old){if(old.qty>=v.stock){alert('Estoque máximo para esta variação');return}old.qty++}else state.cart.push({id:vid,productId:p.id,qty:1,size:v.size,color:v.color});saveCart();updateCount();cartDrawer();return}const old=state.cart.find(x=>x.id===p.id);if(old){if(old.qty>=p.stock)return;old.qty++}else state.cart.push({id:p.id,qty:1});saveCart();updateCount();cartDrawer()});if(p.variants?.length){let size=document.createElement('p');size.className='variant-summary';size.textContent=p.variants.filter(v=>v.stock>0).map(v=>v.size+' · '+v.color).join('  |  ')||'Sem tamanhos em estoque';info.append(size)}info.append(cat,name,price,btn);node.append(info);productList.append(node)}
}
$('searchInput').addEventListener('input',e=>{state.search=e.target.value.trim();render()});$('categoryFilter').addEventListener('change',e=>{state.category=e.target.value;render()});$('sort').addEventListener('change',e=>{state.sort=e.target.value;render()});
document.querySelectorAll('[data-filter]').forEach(a=>a.addEventListener('click',()=>{state.category=a.dataset.filter;$('categoryFilter').value=state.category;render()}));
// Produtos oficiais só entram após cadastro validado. A prévia começa com um catálogo vazio.
fetch('data/produtos.json',{cache:'no-store'}).then(r=>{if(!r.ok)throw Error('Catálogo indisponível');return r.json()}).then(a=>{if(!Array.isArray(a))return;const local=readAdminProducts();state.products=(local!==null?local:a).filter(p=>p&&typeof p.id==='string'&&/^[a-zA-Z0-9_-]+$/.test(p.id)&&typeof p.name==='string'&&p.name.trim().length>1&&allowedCategories.includes(p.category)&&typeof p.price==='number'&&Number.isFinite(p.price)&&p.price>=0&&Number.isSafeInteger(p.stock)&&p.stock>=0).slice(0,200);render()}).catch(()=>{state.products=readAdminProducts()||[];render()});
updateCount();render();

// V2.0: somente prévia local. Não sincroniza produtos entre dispositivos ou com servidor.
function readAdminProducts(){try{const raw=localStorage.getItem('oss_products_v20');if(raw===null)return null;const obj=JSON.parse(raw);return Array.isArray(obj)?obj:null}catch{return null}}
window.addEventListener('storage',e=>{if(e.key==='oss_products_v20'){state.products=readAdminProducts()||[];state.cart=state.cart.filter(x=>state.products.some(p=>p.id===(x.productId||x.id)));saveCart();updateCount();render()}});
