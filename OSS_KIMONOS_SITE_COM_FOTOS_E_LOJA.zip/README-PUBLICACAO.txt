OSS KIMONOS - PACOTE PARA PUBLICACAO

Envie todos os arquivos e pastas deste ZIP na raiz do repositorio GitHub felipemoura-code/oss-kimonos-site.
Os arquivos index.html e loja.html devem ficar na raiz. As fotos ficam em assets/.
Este pacote contem fotos OSS do projeto anterior. WhatsApp: (19) 99712-1912.
Nao há produtos com preços ou estoque confirmados; a compra e por atendimento.
Nao exclua arquivos do repositorio que nao estejam neste pacote sem verificar.
